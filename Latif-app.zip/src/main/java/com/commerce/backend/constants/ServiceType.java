package com.commerce.backend.constants;

public enum ServiceType {
 HOUSING,
 HOSTERLY,
 DLIVERY,
 SHOWER
}
