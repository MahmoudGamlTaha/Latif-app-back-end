package com.commerce.backend.constants;

public enum UserType {
   ADMIN,
   VISITOR,
   USER,
   DRIVER,
   DOCTOR,
   SELLER
}
