package com.commerce.backend.constants;

public enum ItemType {
	  PET,
	  ACCESSORIES,
	  SERVICE
}
