package com.commerce.backend.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.commerce.backend.model.entity.UserAds;

@Repository
public interface UserAdsRepositoryCustom<T extends UserAds>{ 
}
