package com.commerce.backend.dao;

import java.util.List;
import com.commerce.backend.model.entity.UserServiceAds;

public interface UserServiceAdsRepoCustom{
   List<UserServiceAds> findAllMobile();
}
