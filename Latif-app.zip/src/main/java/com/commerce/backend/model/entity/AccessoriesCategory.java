package com.commerce.backend.model.entity;

import javax.persistence.DiscriminatorValue;

@DiscriminatorValue("2")
public class AccessoriesCategory extends ItemObjectCategory {

}
