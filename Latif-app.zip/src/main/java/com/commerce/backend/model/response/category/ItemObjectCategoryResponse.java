package com.commerce.backend.model.response.category;

import com.commerce.backend.model.dto.ItemObjectCategoryVO;
import lombok.Data;

@Data
public class ItemObjectCategoryResponse {
    private ItemObjectCategoryVO category;
}