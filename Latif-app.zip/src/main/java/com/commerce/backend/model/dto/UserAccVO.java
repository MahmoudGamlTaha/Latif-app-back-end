package com.commerce.backend.model.dto;

public class UserAccVO extends UserAdsVO {

}
