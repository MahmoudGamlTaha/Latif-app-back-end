package com.commerce.backend.model.dto;

public class UserServiceVO extends UserAdsVO {

}
