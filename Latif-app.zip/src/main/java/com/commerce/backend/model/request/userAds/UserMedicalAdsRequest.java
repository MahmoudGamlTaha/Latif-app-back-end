package com.commerce.backend.model.request.userAds;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserMedicalAdsRequest extends UserServiceAdsRequest{
  
}
