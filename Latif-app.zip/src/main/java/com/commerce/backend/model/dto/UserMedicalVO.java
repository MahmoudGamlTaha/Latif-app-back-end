package com.commerce.backend.model.dto;

public class UserMedicalVO extends UserAdsVO {

}
