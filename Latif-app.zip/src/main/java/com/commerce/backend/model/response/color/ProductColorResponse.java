package com.commerce.backend.model.response.color;

import com.commerce.backend.model.dto.ColorDTO;
import lombok.Data;

@Data
public class ProductColorResponse {
    private ColorDTO color;
}
